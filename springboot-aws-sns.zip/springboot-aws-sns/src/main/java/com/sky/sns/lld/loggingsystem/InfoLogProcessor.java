package com.sky.sns.lld.loggingsystem;

public class InfoLogProcessor extends LogProcessor{

    public InfoLogProcessor(LogProcessor nextLogProcessor) {
        super(nextLogProcessor);
    }

    public void log(int limit, String message){
        if (limit == INFO){
            System.out.println("Info Logger prints"+message);
        }else {
            super.log(limit,message);
        }

    }
}
