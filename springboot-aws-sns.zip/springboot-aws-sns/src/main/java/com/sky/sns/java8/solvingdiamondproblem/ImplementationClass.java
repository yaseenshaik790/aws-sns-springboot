package com.sky.sns.java8.solvingdiamondproblem;

public class ImplementationClass implements IneterfaceOne,IneterfaceTwo{

    @Override
    public void m1() {
        IneterfaceOne.super.m1();
    }

    public static void main(String[] args) {
        ImplementationClass aClass = new ImplementationClass();
        aClass.m1();
    }
}
