package com.sky.sns.designpatterns.strategy.with.strategy;

public class NormalDriveCapability implements DriveStrategy {
    @Override
    public void drive() {
        System.out.println("Normal Drive Capability");
    }
}
