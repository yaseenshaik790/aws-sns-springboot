package com.sky.sns.designpatterns.strategy.oneMore;

public class Calculator {

    public static void main(String[] args) {

        CalculatorFactory subtractFactory = new CalculatorFactory(new SubstractOperation());
        subtractFactory.calculate(22,11);
        CalculatorFactory addCalculatorFactory = new CalculatorFactory(new SubstractOperation());
        addCalculatorFactory.calculate(22,11);
    }
}
