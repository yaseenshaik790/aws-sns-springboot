package com.sky.sns.designpatterns.strategy.oneMore;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class CalculatorFactory {

    private Strategy strategy;

    public void calculate(int num1, int num2){
        strategy.doOperations(num1,num2);
    }
}
