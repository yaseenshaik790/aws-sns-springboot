package com.sky.sns.designpatterns.observerPattern;

import com.sky.sns.designpatterns.observerPattern.observable.IphoneStockObservable;
import com.sky.sns.designpatterns.observerPattern.observable.OnePlusStockObservable;
import com.sky.sns.designpatterns.observerPattern.observable.StockObservable;
import com.sky.sns.designpatterns.observerPattern.observer.EmailNotification;
import com.sky.sns.designpatterns.observerPattern.observer.NotificationAlertObserver;

public class Store {

    public static void main(String[] args) {
        StockObservable iphoneStockObservable= new IphoneStockObservable();
        StockObservable onePlusObservable= new OnePlusStockObservable();
        NotificationAlertObserver notificationAlert = new EmailNotification(iphoneStockObservable,"yaseen");
        NotificationAlertObserver notificationAlert2 = new EmailNotification(iphoneStockObservable,"Harsha");
        NotificationAlertObserver notificationAlert3 = new EmailNotification(onePlusObservable,"Darling");
        iphoneStockObservable.add(notificationAlert);
        iphoneStockObservable.add(notificationAlert2);
        onePlusObservable.add(notificationAlert3);
        iphoneStockObservable.setCount(10);
        onePlusObservable.setCount(12);
    }
}
