package com.sky.sns.designpatterns.bridge.implementor.impl;

import com.sky.sns.designpatterns.bridge.implementor.BreathImplementator;

public class WaterBreathImplementator implements BreathImplementator {
    @Override
    public void breath() {
        System.out.println("Breath from Water");
    }
}
