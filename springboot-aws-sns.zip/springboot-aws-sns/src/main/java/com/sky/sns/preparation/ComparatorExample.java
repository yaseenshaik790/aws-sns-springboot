package com.sky.sns.preparation;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@Data
@AllArgsConstructor
class Employee {

    private Integer id;
    private String name;
    private Integer age;
}

class AgeComparator implements Comparator<Employee>{

    @Override
    public int compare(Employee o1, Employee o2) {
        if (o1.getAge() == o2.getAge()){
            return 0;
        }else if (o1.getAge() > o2.getAge()){
            return 1;
        } else {
            return -1;
        }
    }
}
public class ComparatorExample {

    public static void main(String[] args) {
        //Comparable
        Employee student = new Employee(1, "Harsh",20);
        Employee student2 = new Employee(1, "Harsh",30);
        Employee student3 = new Employee(1, "Harsh",25);
        List<Employee> students = Arrays.asList(student,student2,student3);
        Collections.sort(students, new AgeComparator());
        for(Employee s:students){
            System.out.println(s.getAge());
        }
    }
}
