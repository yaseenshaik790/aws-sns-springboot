package com.sky.sns.designpatterns.strategy.oneMore;

public class AddOperation implements Strategy{
    @Override
    public void doOperations(int num1, int num2) {
        System.out.println(num1+num2);
    }
}
