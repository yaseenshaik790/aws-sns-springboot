package com.sky.sns.designpatterns.adapterPattern.client;

import com.sky.sns.designpatterns.adapterPattern.adapter.WeighingMachine;
import com.sky.sns.designpatterns.adapterPattern.adaptive.WeighingMachinForBabies;
import com.sky.sns.designpatterns.adapterPattern.adaptive.WeighingMachineForBabiesConcrete;

public class Client {
    public static void main(String[] args) {
        WeighingMachinForBabies machineForBabies = new WeighingMachineForBabiesConcrete();
        WeighingMachine weighingMachine = new WeighingMachine(machineForBabies);
        System.out.println(weighingMachine.getWeight());
    }
}
