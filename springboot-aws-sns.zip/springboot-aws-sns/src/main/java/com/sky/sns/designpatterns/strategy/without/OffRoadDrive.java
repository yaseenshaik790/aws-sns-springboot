package com.sky.sns.designpatterns.strategy.without;

public class OffRoadDrive extends Vehicle{

    public void drive() {
        System.out.println("Special Drive Capability");
    }
}
