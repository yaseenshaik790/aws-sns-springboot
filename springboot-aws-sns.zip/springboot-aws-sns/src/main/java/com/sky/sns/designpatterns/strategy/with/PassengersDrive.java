package com.sky.sns.designpatterns.strategy.with;

import com.sky.sns.designpatterns.strategy.with.strategy.NormalDriveCapability;

public class PassengersDrive extends VehicleFactory {

    public PassengersDrive(){
        super(new NormalDriveCapability());
    }
}
