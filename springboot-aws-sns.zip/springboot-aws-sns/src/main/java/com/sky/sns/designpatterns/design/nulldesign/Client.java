package com.sky.sns.designpatterns.design.nulldesign;

public class Client {
    public static void main(String[] args) {
        Vehicle factory = VehicleFactory.getVehicle(new Audi());
        System.out.println(factory.getVehicleMileage());
        System.out.println(factory.getVehicleFuel());
    }
}
