package com.sky.sns.utils;


import com.sky.sns.model.EmployeeResponse;
import com.sky.sns.model.Employeee;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Component
public class MockDataUtils {

    Employeee employeee = new Employeee(1, "As", 200.0);
    Employeee employeee2 = new Employeee(2, "As", 2050.0);
    Employeee employeee3 = new Employeee(3, "As", 25600.0);
    Employeee employeee4 = new Employeee(4, "As", 2060.0);
    Employeee employeee5 = new Employeee(5, "As", 2300.0);
    Employeee employeee6 = new Employeee(6, "As", 2600.0);
    Employeee employeee7 = new Employeee(7, "As", 20530.0);
    Employeee employeee8 = new Employeee(8, "As", 2005.0);
    Employeee employeee9 = new Employeee(9, "As", 25300.0);
    Employeee employeee10 = new Employeee(10, "As", 2500.0);
    Employeee employeee11 = new Employeee(11, "As", 2500.0);
    Employeee employeee12 = new Employeee(12, "As", 2050.0);
    Employeee employeee13 = new Employeee(13, "As", 2300.0);
    Employeee employeee14 = new Employeee(14, "As", 200.0);
    Employeee employeee15 = new Employeee(15, "As", 2030.0);
    Employeee employeee16 = new Employeee(16, "As", 2300.0);
    Employeee employeee17 = new Employeee(17, "As", 2300.0);
    Employeee employeee18 = new Employeee(18, "As", 200.0);
    Employeee employeee19 = new Employeee(19, "As", 2200.0);
    Employeee employeee20 = new Employeee(20, "As", 200.0);
    Employeee employeee21 = new Employeee(21, "As", 2200.0);
    Employeee employeee22 = new Employeee(22, "As", 200.0);
    Employeee employeee23 = new Employeee(23, "As", 2020.0);
    Employeee employeee24 = new Employeee(24, "As", 2020.0);
    Employeee employeee25 = new Employeee(25, "As", 2050.0);
    Employeee employeee26 = new Employeee(26, "As", 2020.0);
    Employeee employeee27 = new Employeee(27, "As", 2020.0);
    Employeee employeee28 = new Employeee(28, "As", 200.0);
    Employeee employeee29 = new Employeee(29, "As", 2300.0);
    Employeee employeee30 = new Employeee(30, "As", 2050.0);

    List<Employeee> employeees = Arrays.asList(employeee,employeee2,employeee3,employeee4,employeee5,employeee6,
            employeee6,employeee7,employeee9,employeee7,employeee8,employeee9,employeee10,employeee11,employeee12,
            employeee13,employeee14,employeee15,employeee16,employeee30,employeee29,employeee28,employeee27,
            employeee26,employeee25,employeee24,employeee23,employeee22,employeee21,employeee20,employeee19,employeee18,employeee17);


    public EmployeeResponse makeAsyncCall(int size){
        log.info("Asyn enter "+Thread.currentThread().getName());
        EmployeeResponse employeeResponse = new EmployeeResponse();
        List<Employeee> list = employeees.stream().filter(emp -> emp.getId() < size)
                .collect(Collectors.toList());
        employeeResponse.setEmployeees(list);
        log.info("Asyn exit "+Thread.currentThread().getName());
        return employeeResponse;
    }

}
