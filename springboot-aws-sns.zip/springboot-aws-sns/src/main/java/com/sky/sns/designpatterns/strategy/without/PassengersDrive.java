package com.sky.sns.designpatterns.strategy.without;

public class PassengersDrive extends Vehicle{

}
