package com.sky.sns.designpatterns.bridge.implementor.impl;

import com.sky.sns.designpatterns.bridge.implementor.BreathImplementator;

public class H2OBreathImplementator implements BreathImplementator {
    @Override
    public void breath() {
        System.out.println("Breath from H2O AIR");
    }
}
