package com.sky.sns.lld.loggingsystem.atm;

public class FiveHundredHandler extends ATMMachineHandler{

    public FiveHundredHandler(ATMMachineHandler nextATMachineHandler) {
        super(nextATMachineHandler);
    }

    public void passOn(int handlerLevel, String message){
        if (handlerLevel == FIVE_HUNDRED){
            System.out.println("Please take 500 notes "+message);
        }else {
            super.passOn(handlerLevel,message);
        }
    }
}
