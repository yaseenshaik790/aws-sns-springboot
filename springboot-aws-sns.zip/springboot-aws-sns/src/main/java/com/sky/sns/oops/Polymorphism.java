package com.sky.sns.oops;

class Shape{
    public void calculate(){
        System.out.println("Print calulate formula");
    }
}
class Rectangular extends Shape{
    public void calculate(){
        System.out.println("Print Rectangular formula");
    }
}
class Circle extends Shape{
    public void calculate(){
        System.out.println("Print Circle formula");
    }
}
public class Polymorphism {
    public static void main(String[] args) {
        /*In Java, polymorphism refers to the ability of a class to provide different implementations of a method,
        depending on the type of object that is passed to the method.
        To put it simply, polymorphism in Java allows us to perform the same action in many different ways.*/
        Shape shape = new Shape();
        Shape rect = new Rectangular();
        Shape circle = new Circle();
        shape.calculate();
        rect.calculate();
        circle.calculate();
    }
}
