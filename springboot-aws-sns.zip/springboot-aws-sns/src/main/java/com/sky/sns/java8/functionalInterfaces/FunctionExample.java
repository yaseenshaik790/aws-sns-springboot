package com.sky.sns.java8.functionalInterfaces;


import java.util.function.Function;
import java.util.function.Predicate;

public class FunctionExample {

    static void add(int age,int ab){
        System.out.println(age+ab);
    }
    public static void main(String[] args){

        Function<Integer,Integer> function =  i -> i*i;
        System.out.println(function.apply(10));
        //function.apply(25);

    }
}
