package com.sky.sns.designpatterns.bridge.service.impl;

import com.sky.sns.designpatterns.bridge.implementor.BreathImplementator;
import com.sky.sns.designpatterns.bridge.service.LivingThings;

public class TreeBreathImpl extends LivingThings {

    public TreeBreathImpl(BreathImplementator breathImplementator) {
        super(breathImplementator);
    }

    @Override
    public void buildBreathProcessor() {
    super.buildBreathProcessor();
    }
}
