package com.sky.sns.java8.repository;

import com.sky.sns.java8.entity.Change;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChangeRepository extends JpaRepository<Change,Integer> {

}
