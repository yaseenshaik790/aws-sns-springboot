package com.sky.sns.designpatterns.adapterPattern.adapter;

import com.sky.sns.designpatterns.adapterPattern.adaptive.WeighingMachinForBabies;
import lombok.AllArgsConstructor;


@AllArgsConstructor
public class WeighingMachine implements WeighingMachin {

    WeighingMachinForBabies weighingMachineForBabies;

    @Override
    public int getWeight() {
        int weight = weighingMachineForBabies.getWeightForBabies();
        return weight+10;
    }
}
