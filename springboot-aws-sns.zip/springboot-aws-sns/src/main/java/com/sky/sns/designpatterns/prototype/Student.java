package com.sky.sns.designpatterns.prototype;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
public class Student implements ProtoType{

    int id;
    private String name;
    int age;


    @Override
    public ProtoType clone() {
        return new Student(id, name, age);
    }
}
