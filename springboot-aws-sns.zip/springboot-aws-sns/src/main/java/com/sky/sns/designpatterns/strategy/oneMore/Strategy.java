package com.sky.sns.designpatterns.strategy.oneMore;

public interface Strategy {

    void doOperations(int num1, int num2);
}
