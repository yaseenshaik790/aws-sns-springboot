package com.sky.sns.designpatterns.prototype;

public class Client {
    public static void main(String[] args) {
        Student student = new Student(1, "yaseen", 20);
        System.out.println(student);

        Student cloneObj = (Student) student.clone();
        cloneObj.setName("Harsha");
        cloneObj.setId(1);
        cloneObj.setAge(22);
        System.out.println(cloneObj);
    }
}
