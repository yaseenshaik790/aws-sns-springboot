package com.sky.sns.designpatterns.adapterPattern.adaptive;

public interface WeighingMachinForBabies {

    //in Pounds
    int getWeightForBabies();
}
