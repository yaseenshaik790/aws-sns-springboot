package com.sky.sns.lld.loggingsystem.atm;

public class User {
    public static void main(String[] args) {
        ATMMachineHandler machineHandler = new TwoThousandHandler(new FiveHundredHandler(new OneHundredHandler(null)));

        machineHandler.passOn(ATMMachineHandler.TWO_THOUSAND,"I want 2000 rupees");
    }
}
