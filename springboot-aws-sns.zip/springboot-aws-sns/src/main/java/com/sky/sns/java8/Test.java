package com.sky.sns.java8;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.*;
import java.util.stream.Collectors;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
class Employee{
    int id;
    String name;
    Double sal;
}

public class Test {
    public static void main(String[] args) {
        List<Employee> list = new ArrayList<>();
        list.add(new Employee(1,"h",2000.00));
        list.add(new Employee(2,"a",2030.00));
        list.add(new Employee(3,"r",2020.00));
        list.add(new Employee(5,"t",20110.00));
        list.add(new Employee(4,"a",20330.00));

        //Desc order
        List<Employee> employ = list.stream().sorted(Comparator.comparing(Employee::getId))
                .collect(Collectors.toList());
        employ.forEach(emp3 -> System.out.print(emp3.getId()+" "));

        //Asceneding
        list.sort(Comparator.comparingDouble(Employee::getSal));
        list.forEach(emp3 -> System.out.print("Asc " + emp3.getId()+" "));

        //Descending
        list.sort(Comparator.comparingDouble(Employee::getSal).reversed());
        list.forEach(emp3 -> System.out.print("Desc " + emp3.getId()+" "));

        //Sal list
        List<Double> sal = list.stream().map(Employee::getSal)
                .filter(empSal -> empSal >100).collect(Collectors.toList());
        System.out.println("Only Sal "+sal);
        //Only Price
        double sumValue = list.stream().mapToDouble(Employee::getSal).sum();
        System.out.println("Sum "+sumValue);
        //Summing Double
        Double price = list.stream().map(Employee::getSal).reduce(0.0,Double::sum);
        System.out.println("Summing Double "+price);
        //Max Double
        //Only Map to Double
        Double aDouble = list.stream().mapToDouble(Employee::getSal).max().getAsDouble();
        Employee employee = list.stream().max(Comparator.comparing(Employee::getSal)).get();
        System.out.println("Max "+employee.getSal());
        //Min Double
        Employee emp = list.stream().min(Comparator.comparing(Employee::getSal)).get();
        System.out.println("Min "+emp.getSal());
        //Set
        Set<Double> prices = list.stream().map(Employee::getSal).collect(Collectors.toSet());
        System.out.println("Set "+prices);
        //map
        Map<Integer,String> map = list.stream().collect(Collectors.toMap(Employee::getId,Employee::getName));
        System.out.println("map "+map);
        //FlatMap : Performs Map operation and flattering operations
        List<List<Integer>> ints = Arrays.asList(Arrays.asList(5, 7, 11,13),Arrays.asList(1, 3, 5),Arrays.asList(2, 4, 6, 8));
        System.out.println("Before flattering "+ints);
        List<Integer> finalSol = ints.stream().flatMap(listInts -> listInts.stream())
                .collect(Collectors.toList());
        System.out.println("After flattering "+finalSol);


        //How to get Unique Elements from List
        Set<String> uniqueEle = new HashSet<>();
        Set<String> employees = list.stream().map(Employee::getName).filter(name -> !uniqueEle.add(name))
                .collect(Collectors.toSet());
        employees.forEach(employee1 -> System.out.println("Unique records "+employee1));

        //Desc Order

    }
}













    /*List<Double> sal = list.stream().map(Employee::getSal)
            .filter(employeeSal -> employeeSal > 200).collect(Collectors.toList());
        System.out.println(sal);
        //Only Price
        Double value = list.stream().map(Employee::getSal).reduce(0.0,Double::sum);
        System.out.println("Sum "+value);
        //Summing Double
        double price = list.stream().mapToDouble(Employee::getSal).sum();
        System.out.println("Summing Double "+price);
        //Max Double
        Employee maxPrice = list.stream().max(Comparator.comparing(Employee::getSal)).get();
        System.out.println("Max "+maxPrice.getSal());
        //Min Double
        Employee minPrice = list.stream().min(Comparator.comparing(Employee::getSal)).get();
        System.out.println("Min "+minPrice.getSal());
        //Set
        Set<Double> hashSet = list.stream().map(Employee::getSal).collect(Collectors.toSet());
        System.out.println("Set "+hashSet);
        //map
        Map<Integer,String> map = list.stream().collect(Collectors.toMap(Employee::getId,Employee::getName));
        System.out.println("map "+map);*/
