package com.sky.sns.multithreading;

public class ThreadDemo extends Thread{

    public void run(){
        System.out.println("Hi");
    }
    public static void main(String[] args) {
        ThreadDemo threaddemo = new ThreadDemo();
        threaddemo.start();
    }
}
