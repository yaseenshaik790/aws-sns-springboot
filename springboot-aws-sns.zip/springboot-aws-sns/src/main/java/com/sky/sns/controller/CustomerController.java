package com.sky.sns.controller;

import com.sky.sns.service.CustomerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @GetMapping(value = "/customers")
    public Object getCustomers() {
        return customerService.getCustomer();
    }

    @Value("${check.props}")
    private String value;

    @GetMapping("/get")
    public String get() {
        return value;
    }

}
