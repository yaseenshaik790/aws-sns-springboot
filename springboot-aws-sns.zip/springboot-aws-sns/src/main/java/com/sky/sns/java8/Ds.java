package com.sky.sns.java8;

import java.util.Collections;
import java.util.PriorityQueue;

public class Ds {

    public static void main(String[] args) {
        PriorityQueue<Integer> priorityQueue = new PriorityQueue<>(Collections.reverseOrder());
        int[] a = new int[]{2,44,22,4,111,45};
        for (int val:a){
            priorityQueue.add(val);
        }

        for (int val:a){
            System.out.println(priorityQueue.peek());
            priorityQueue.remove(val);
        }
    }

    public static int maxProfit(int[] prices) {

        int max = 0;
        int min = Integer.MAX_VALUE;

        for(int i=0; i< prices.length; i++){
            if (prices[i] < min){
                min = prices[i];
            }else {
                max = Math.max(max, prices[i]-min);
            }
        }
        return  max;
    }
}
