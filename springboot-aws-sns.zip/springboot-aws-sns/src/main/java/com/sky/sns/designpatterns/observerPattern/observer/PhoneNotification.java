package com.sky.sns.designpatterns.observerPattern.observer;

import com.sky.sns.designpatterns.observerPattern.observable.StockObservable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PhoneNotification implements NotificationAlertObserver {

    private String phone;

    @Override
    public void update() {
        System.out.println("phone send no: "+phone);
    }
}
