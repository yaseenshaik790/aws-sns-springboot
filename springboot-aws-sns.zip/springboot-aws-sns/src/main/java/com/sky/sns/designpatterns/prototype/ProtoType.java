package com.sky.sns.designpatterns.prototype;

public interface ProtoType {
    ProtoType clone();
}
