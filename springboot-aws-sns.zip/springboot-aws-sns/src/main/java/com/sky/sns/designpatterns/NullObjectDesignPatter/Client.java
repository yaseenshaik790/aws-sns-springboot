package com.sky.sns.designpatterns.NullObjectDesignPatter;

public class Client {
    public static void main(String[] args) {
        Vehicle vehicle = VehicleFactory.getVehicle("Audi");
        System.out.println("name " + vehicle.getVehicleName());
        System.out.println("fuel " + vehicle.getFuelCapacity());

    }
}
