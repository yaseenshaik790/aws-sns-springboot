package com.sky.sns.java8.staticmethod;

public interface IneterfaceOne {

    static void m1(){
        System.out.println("Interface One");
    }
}
