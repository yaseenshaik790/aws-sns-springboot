package com.sky.sns.lld.loggingsystem.atm;

public class OneHundredHandler extends ATMMachineHandler{

    public OneHundredHandler(ATMMachineHandler nextATMachineHandler) {
        super(nextATMachineHandler);
    }

    public void passOn(int handlerLevel, String message){
        if (handlerLevel == ONE_HUNDRED){
            System.out.println("Please take 100 notes "+message);
        }else {
            super.passOn(handlerLevel,message);
        }
    }
}
