package com.sky.sns.designpatterns.bridge.implementor;

public interface BreathImplementator {
    void breath();
}
