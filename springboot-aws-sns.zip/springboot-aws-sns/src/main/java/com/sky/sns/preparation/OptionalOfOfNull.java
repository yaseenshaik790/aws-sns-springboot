package com.sky.sns.preparation;

import java.util.Optional;

public class OptionalOfOfNull {

    public static void main(String[] args) {
        String s = null;

        Optional<String> d = Optional.of(s);
        System.out.println(d.get());
        Optional<String> f = Optional.ofNullable(s);
        System.out.println(f.get());
    }
}
