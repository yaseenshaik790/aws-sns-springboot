package com.sky.sns.preparation;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

@Data
@AllArgsConstructor
class Student implements Comparable<Student> {

    private Integer id;
    private String name;
    private Integer age;

    @Override
    public int compareTo(Student s) {
        if (s.age == age) {
            return 0;
        } else if (s.age > age) {
            return 1;
        } else {
            return -1;
        }
    }
}

public class ComparableExample {
    public static void main(String[] args) {

        //Comparable
        Student student = new Student(1, "Harsh",20);
        Student student2 = new Student(1, "Harsh",30);
        Student student3 = new Student(1, "Harsh",25);
        List<Student> students = Arrays.asList(student,student2,student3);
        Collections.sort(students);
        for(Student s:students){
            System.out.println(s.getAge());
        }

    }
}
