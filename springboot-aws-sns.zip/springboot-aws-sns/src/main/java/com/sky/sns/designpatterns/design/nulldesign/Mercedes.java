package com.sky.sns.designpatterns.design.nulldesign;

public class Mercedes implements Vehicle{
    @Override
    public int getVehicleFuel() {
        return 100;
    }

    @Override
    public int getVehicleMileage() {
        return 124;
    }
}
