package com.sky.sns.designpatterns.strategy.with.strategy;

public class XYZCapability implements DriveStrategy {

    @Override
    public void drive() {
        System.out.println("XYZ Drive Capability");
    }
}
