package com.sky.sns.java8.solvingdiamondproblem;

public interface IneterfaceTwo {
    default void m1(){
        System.out.println("Interface Two");
    }
}
