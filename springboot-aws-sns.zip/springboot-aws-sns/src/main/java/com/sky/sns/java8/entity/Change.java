package com.sky.sns.java8.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "change",schema = "dummy")
@Builder
@AllArgsConstructor@NoArgsConstructor
@Data
public class Change {

    @Id
    private Integer id;
    private String name;
}
