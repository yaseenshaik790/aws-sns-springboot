package com.sky.sns.multithreading;

import lombok.SneakyThrows;

class CommonClass{
    public synchronized void print() throws InterruptedException {
        for (int i=0; i<3; i++){
            Thread.sleep(3000);
            System.out.println(i);
        }
    }

}

class ThreadOne extends Thread{
    CommonClass commonClass;
    public ThreadOne(CommonClass commonClass){
        this.commonClass = commonClass;
    }

    @SneakyThrows
    public void run(){
        commonClass.print();
    }
}

class ThreadTwo extends Thread{
    CommonClass commonClass;
    public ThreadTwo(CommonClass commonClass){
        this.commonClass = commonClass;
    }
    @SneakyThrows
    public void run(){
        commonClass.print();
    }

}
public class SynchronizedExample {
    public static void main(String[] args) {
        CommonClass aClass = new CommonClass();
        ThreadOne threadOne = new ThreadOne(aClass);
        ThreadTwo threadTwo = new ThreadTwo(aClass);
        threadOne.start();
        threadTwo.start();
    }
}
