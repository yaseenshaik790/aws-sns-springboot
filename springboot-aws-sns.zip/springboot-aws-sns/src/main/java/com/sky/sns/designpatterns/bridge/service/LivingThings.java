package com.sky.sns.designpatterns.bridge.service;

import com.sky.sns.designpatterns.bridge.implementor.BreathImplementator;

public class LivingThings {

    BreathImplementator breathImplementator;

    public LivingThings(BreathImplementator breathImplementator){
        this.breathImplementator = breathImplementator;
    }

    public void buildBreathProcessor(){
        breathImplementator.breath();
    }
}
