package com.sky.sns.designpatterns.NullObjectDesignPatter;

public class NullObject implements Vehicle{
    @Override
    public int getFuelCapacity() {
        return 0;
    }

    @Override
    public String getVehicleName() {
        return null;
    }
}
