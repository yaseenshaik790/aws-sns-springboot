package com.sky.sns.controller;

import com.sky.sns.java8.ChangeRequest;
import com.sky.sns.java8.builder.ChangeRequestService;
import com.sky.sns.service.AmazonSNSSrervice;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
public class AmazonSNSController {

    @Autowired
    private AmazonSNSSrervice amazonSNSSrervice;

    @Autowired
    private ChangeRequestService changeRequestService;

    @PostMapping(value = "/change")
    public void publish(@RequestBody ChangeRequest message) {
        changeRequestService.accept(message);
    }

    @PostMapping(value = "/subscribe/{email}")
    @ResponseStatus(HttpStatus.CREATED)
    public Object subscribe(@PathVariable String email) {
        return amazonSNSSrervice.subscribe(email);
    }

    @PostMapping(value = "/publish")
    @ResponseStatus(HttpStatus.OK)
    public Object publish(@RequestParam String message) {
        return amazonSNSSrervice.publish(message);
    }

    @PostMapping("/{token}")
    public void createEndpoint(@PathVariable("token") String token) {
        amazonSNSSrervice.createEndpoint(token);
    }
}
