package com.sky.sns.designpatterns.design.nulldesign;

public interface Vehicle {
    int getVehicleFuel();
    int getVehicleMileage();
}
