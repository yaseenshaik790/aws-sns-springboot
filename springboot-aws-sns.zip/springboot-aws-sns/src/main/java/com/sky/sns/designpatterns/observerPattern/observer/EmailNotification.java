package com.sky.sns.designpatterns.observerPattern.observer;

import com.sky.sns.designpatterns.observerPattern.observable.StockObservable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmailNotification implements NotificationAlertObserver {

    private String email;

    public EmailNotification(StockObservable iphoneStockObservable, String yaseen) {
    }

    @Override
    public void update() {
        System.out.println("email send id: "+email);
    }
}
