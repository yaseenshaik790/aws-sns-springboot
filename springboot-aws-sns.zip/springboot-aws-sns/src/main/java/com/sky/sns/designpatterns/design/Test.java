package com.sky.sns.designpatterns.design;

public class Test {
}
