package com.sky.sns.lld.loggingsystem;

public class DebugLogProcessor extends LogProcessor{

    public DebugLogProcessor(LogProcessor nextLogProcessor) {
        super(nextLogProcessor);
    }

    public void log(int logLevel, String message){
        if (logLevel == DEBUG){
            System.out.println("Debug Logger prints"+message);
        }else {
            super.log(logLevel,message);
        }

    }
}
