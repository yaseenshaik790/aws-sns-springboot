package com.sky.sns.designpatterns.NullObjectDesignPatter;


public class VehicleFactory {

    public static Vehicle getVehicle(String vehicle){
        if (vehicle.equalsIgnoreCase("Audi")){
            return new AudiCar();
        } else {
            return new NullObject();
        }

    }
}
