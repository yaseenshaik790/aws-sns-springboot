package com.sky.sns.designpatterns.adapterPattern.adapter;

public interface WeighingMachin {

    //in Kgs
    int getWeight();
}
