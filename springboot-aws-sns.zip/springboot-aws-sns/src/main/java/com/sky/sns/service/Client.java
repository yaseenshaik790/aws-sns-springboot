package com.sky.sns.service;

import java.util.*;
import java.util.stream.Collectors;

public class Client {

    public static void main(String[] args) {
        Student student = new Student(1, "Hars", "Nlr");
        Student student1 = new Student(2, "Pars", "A");
        Student student2 = new Student(3, "Yeast", "R");

        Department department = new Department(1, "Maths", student);
        Department department2 = new Department(2, "Physi", student);
        Department department3 = new Department(3, "Hind", student1);
        Department department4 = new Department(4, "Eng", student1);
        Department department5 = new Department(5, "Sansc", student2);
        Department department6 = new Department(6, "Biology", student2);

        List<Department> departments = Arrays.asList(department, department2, department3, department4, department5, department6);

        List<String> list = Arrays.asList("Physi", "Hind");
        Map<Integer, Department> map = new HashMap<>();
        departments.forEach(departme -> map.put(departme.getStudent().getId(), departme));
        List<Department> departmentList= new ArrayList<>();

        /*map.forEach((str, dep) -> {
            if (list.contains(str)){
                departmentList.add(dep);
            }
        });*/
        System.out.println(map);
    }
}
