package com.sky.sns.lld.loggingsystem.atm;

public class TwoThousandHandler extends ATMMachineHandler{

    public TwoThousandHandler(ATMMachineHandler nextATMachineHandler) {
        super(nextATMachineHandler);
    }

    public void passOn(int handlerLevel, String message){
        if (handlerLevel == TWO_THOUSAND){
            System.out.println("Please take 2000 notes "+message);
        }else {
            super.passOn(handlerLevel,message);
        }
    }
}
