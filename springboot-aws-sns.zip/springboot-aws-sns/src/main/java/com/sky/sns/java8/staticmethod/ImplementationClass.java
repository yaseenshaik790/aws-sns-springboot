package com.sky.sns.java8.staticmethod;

public class ImplementationClass {

    //High performance and No space is required compare to class( constructor,etc)
    public static void main(String[] args) {
        IneterfaceOne.m1();
    }
}
