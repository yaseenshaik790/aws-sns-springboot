package com.sky.sns.designpatterns.strategy.with.strategy;

public interface DriveStrategy {
    void drive();
}
