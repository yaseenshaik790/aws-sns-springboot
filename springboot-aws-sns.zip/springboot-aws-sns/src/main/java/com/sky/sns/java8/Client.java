package com.sky.sns.java8;

import java.util.function.BiConsumer;
import java.util.function.Consumer;

@FunctionalInterface
interface FunctionalInterfaceDemo {

    void add(int a,int b);

    static void printDoc(){
        System.out.println("printDoc");
    }

    static void print(String s) {
        System.out.println("Print "+s);
    }
}

public class Client implements FunctionalInterfaceDemo{

    @Override
    public void add(int a,int b) {
        System.out.println("Add "+a+b);
    }

    public static void main(String[] args) {

        FunctionalInterfaceDemo interfaceDemo = new Client();
        interfaceDemo.add(10,20);
        Consumer<String> consumer =  FunctionalInterfaceDemo::print;
        consumer.accept("HI");
        BiConsumer<Integer,Integer> bicons = (a,b)->System.out.println(a+b);
        bicons.accept(10,20);
    }
}
