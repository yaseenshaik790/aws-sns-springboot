package com.sky.sns.designpatterns.observerPattern.observer;

public interface NotificationAlertObserver {

    void update();
}
