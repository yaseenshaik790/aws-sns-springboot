package com.sky.sns.designpatterns.bridge;

import com.sky.sns.designpatterns.bridge.implementor.impl.WaterBreathImplementator;
import com.sky.sns.designpatterns.bridge.service.LivingThings;
import com.sky.sns.designpatterns.bridge.service.impl.FishBreathImpl;

public class BridgeClient {

    public static void main(String[] args) {
        LivingThings breathingService = new FishBreathImpl(new WaterBreathImplementator());
        breathingService.buildBreathProcessor();
    }
}
