package com.sky.sns.designpatterns.observerPattern.observable;

import com.sky.sns.designpatterns.observerPattern.observer.NotificationAlertObserver;

import java.util.ArrayList;
import java.util.List;

public class OnePlusStockObservable implements StockObservable {

    private final List<NotificationAlertObserver> notificationAlerts = new ArrayList<>();
    private int stockCount;

    @Override
    public void add(NotificationAlertObserver notificationAlert) {
        notificationAlerts.add(notificationAlert);
    }

    @Override
    public void remove(NotificationAlertObserver notificationAlert) {
        notificationAlerts.remove(notificationAlert);
    }

    @Override
    public void notifySubscriber() {
        for (NotificationAlertObserver notificationAlert : notificationAlerts){
            notificationAlert.update();
        }
    }

    @Override
    public void setCount(int count) {
        if (count != 0){
            notifySubscriber();
        }
        stockCount = stockCount +count;
    }

    @Override
    public int getStockCount() {
        return stockCount;
    }
}
