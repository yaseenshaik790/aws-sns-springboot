package com.sky.sns.designpatterns.observerPattern.observable;

import com.sky.sns.designpatterns.observerPattern.observer.NotificationAlertObserver;

public interface StockObservable {

    void add(NotificationAlertObserver notificationAlertObserver);

    void remove(NotificationAlertObserver notificationAlertObserver);

    void notifySubscriber();

    void setCount(int count);

    int getStockCount();
}
