package com.sky.sns.java8;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ChangeRequest {
    private Integer id;
    private String name;
}
