package com.sky.sns.java8.functionalInterfaces;

import java.util.function.Predicate;

public class PredicateExample {

    static Boolean checkAge(int age){
        return age > 17;
    }

    public static void main(String[] args){
        Predicate<String> check = s -> s.length() >= 3;
        boolean b = check.test("123");
        System.out.println(b);
        // Using Predicate interface
        Predicate<Integer> predicate =  PredicateExample::checkAge;
        // Calling Predicate method
        boolean result = predicate.test(25);
        System.out.println(result);
    }
}
