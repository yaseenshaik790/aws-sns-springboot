package com.sky.sns.designpatterns.bridge.implementor.impl;

import com.sky.sns.designpatterns.bridge.implementor.BreathImplementator;

public class AirBreathImplementator implements BreathImplementator {
    @Override
    public void breath() {
        System.out.println("Breath from AIR");
    }
}
