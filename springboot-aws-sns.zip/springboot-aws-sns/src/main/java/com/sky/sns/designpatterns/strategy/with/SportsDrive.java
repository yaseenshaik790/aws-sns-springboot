package com.sky.sns.designpatterns.strategy.with;

import com.sky.sns.designpatterns.strategy.with.strategy.DriveStrategy;
import com.sky.sns.designpatterns.strategy.with.strategy.SpecialDriveCapability;

public class SportsDrive extends VehicleFactory {

    DriveStrategy drive;
    SportsDrive(DriveStrategy drive) {
        super(new SpecialDriveCapability());
    }
}
