package com.sky.sns.designpatterns.strategy.without;

public class SportsDrive extends Vehicle{
    public void drive() {
        System.out.println("Special Drive Capability");
    }
}
