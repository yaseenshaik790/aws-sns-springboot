package com.sky.sns.lld;

public class Jaclk {
}
