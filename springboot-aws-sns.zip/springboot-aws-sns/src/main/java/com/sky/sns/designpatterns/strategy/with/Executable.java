package com.sky.sns.designpatterns.strategy.with;

public class Executable {
    public static void main(String[] args) {
        VehicleFactory vehicle = new PassengersDrive();
        vehicle.drive();
    }
}
