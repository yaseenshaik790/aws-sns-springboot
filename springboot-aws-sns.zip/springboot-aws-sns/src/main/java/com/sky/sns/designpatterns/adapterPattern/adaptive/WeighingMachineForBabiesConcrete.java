package com.sky.sns.designpatterns.adapterPattern.adaptive;

public class WeighingMachineForBabiesConcrete implements WeighingMachinForBabies{

    @Override
    public int getWeightForBabies() {
        return 10;
    }
}
