package com.sky.sns.designpatterns.design.nulldesign;

public class EmptyObject implements Vehicle{
    @Override
    public int getVehicleFuel() {
        return 0;
    }

    @Override
    public int getVehicleMileage() {
       return 0;
    }
}
