package com.sky.sns.java8.solvingdiamondproblem;

public interface IneterfaceOne {

    default void m1(){
        System.out.println("Interface One");
    }
}
