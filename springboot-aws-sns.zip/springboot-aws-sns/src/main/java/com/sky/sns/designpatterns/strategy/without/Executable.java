package com.sky.sns.designpatterns.strategy.without;

public class Executable {
    public static void main(String[] args) {
        Vehicle vehicle = new SportsDrive();
        vehicle.drive();
    }
}
