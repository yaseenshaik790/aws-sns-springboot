package com.sky.sns.designpatterns.strategy.with;

import com.sky.sns.designpatterns.strategy.with.strategy.DriveStrategy;

public class VehicleFactory {

    private DriveStrategy drive;

    VehicleFactory(DriveStrategy drive){
        this.drive = drive;
    }

    public void drive(){
        this.drive.drive();
    }
}
