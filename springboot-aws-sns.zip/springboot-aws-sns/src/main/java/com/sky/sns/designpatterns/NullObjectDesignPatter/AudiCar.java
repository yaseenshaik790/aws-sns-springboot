package com.sky.sns.designpatterns.NullObjectDesignPatter;

public class AudiCar implements Vehicle{
    @Override
    public int getFuelCapacity() {
        return 50;
    }

    @Override
    public String getVehicleName() {
        return "Audi New Version";
    }
}
