package com.sky.sns.lld.loggingsystem.atm;

public class ATMMachineHandler {
    public static int TWO_THOUSAND = 2000;
    public static int FIVE_HUNDRED = 500;
    public static int ONE_HUNDRED = 100;

    public ATMMachineHandler nextATMachineHandler;

    public ATMMachineHandler(ATMMachineHandler nextATMachineHandler){
        this.nextATMachineHandler = nextATMachineHandler;
    }

    public void passOn(int handlerLevel, String message){
        if (nextATMachineHandler != null){
            nextATMachineHandler.passOn(handlerLevel,message);
        }
    }
}
