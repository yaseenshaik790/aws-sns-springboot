package com.sky.sns.java8.functionalInterfaces;


import java.util.function.Consumer;
import java.util.function.Function;

public class ConsumerExample {

    static void add(int age,int ab){
        System.out.println(age+ab);
    }
    public static void main(String[] args){

        Consumer<String> consumer = i -> System.out.println(i);
        consumer.accept("Jlaka");
        //function.apply(25);

    }
}
