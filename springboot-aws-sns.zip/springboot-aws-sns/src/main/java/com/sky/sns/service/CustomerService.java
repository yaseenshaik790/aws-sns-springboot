package com.sky.sns.service;

import com.sky.sns.model.EmployeeResponse;
import com.sky.sns.utils.MockDataUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.stream.Collectors;

@Slf4j
@Service
public class CustomerService {

    @Autowired
    private MockDataUtils mockDataUtils;

    public Object getCustomer() {
        List<EmployeeResponse> employeeResponse = new ArrayList<>();
        List<CompletableFuture<EmployeeResponse>> completableFutureList = new ArrayList<>();

        for (int count=1; count<= 3; count++){
            int finalSize = count*10;
            CompletableFuture<EmployeeResponse> completableFuture = CompletableFuture.supplyAsync(() ->{
                EmployeeResponse response;
                try {
                    Thread.currentThread().setName("Yaseen "+completableFutureList);
                    log.info("Service enter "+Thread.currentThread());
                    response = mockDataUtils.makeAsyncCall(finalSize);
                }catch (Exception ex){
                    throw new CompletionException(ex);
                }
                log.info("Service exit "+Thread.currentThread());
                return response;
            });
            completableFutureList.add(completableFuture);
        }

        if (!CollectionUtils.isEmpty(completableFutureList)){
            employeeResponse = completableFutureList.stream().map(CompletableFuture::join)
                    .collect(Collectors.toList());
        }
        return employeeResponse;
    }
}
