package com.sky.sns.service;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClient;
import com.amazonaws.services.sns.model.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class AmazonSNSSrervice {

    @Value("${aws.sns.topicArn}")
    private String topicArn;

    @Autowired
    private AmazonSNS amazonSNS;

    @Autowired
    private AmazonSNSClient snsClient;

    public Object subscribe(String email) {
        SubscribeRequest subscribeRequest = new SubscribeRequest(topicArn,"email",email);
        snsClient.subscribe(subscribeRequest);
        return "Subscription was completed with Email ID: "+email;
    }

    public Object publish(String message) {

        PublishRequest request = new PublishRequest(topicArn,message,"Welcome AWS SNS");
        snsClient.publish(request);
        return "Message Sent Successfully";
    }

    public void createEndpoint(String token) {

        CreatePlatformEndpointRequest request = new CreatePlatformEndpointRequest();

        request.setPlatformApplicationArn("arn:aws:sns:us-east-1:060288871868:app/GCM/AndroidApp");
        request.setToken(token);

        log.info("Sending request with token : " + token);
        CreatePlatformEndpointResult platformEndpoint = amazonSNS.createPlatformEndpoint(request);
        log.info("Result : " + platformEndpoint.toString());

        log.info("Creating a topic ...");
        CreateTopicResult topicResult = amazonSNS.createTopic("TEST_MESSAGE_TOPIC");

        SubscribeResult subscribeResult = amazonSNS.subscribe(topicResult.getTopicArn(), "application", platformEndpoint.getEndpointArn());
        log.info("Subscribe result : " + subscribeResult.toString());

        PublishResult publishResult = amazonSNS.publish(topicResult.getTopicArn(), "Hello, dude!"); // public message to topic
        log.info("Publish message result " + publishResult.toString());
    }
}
