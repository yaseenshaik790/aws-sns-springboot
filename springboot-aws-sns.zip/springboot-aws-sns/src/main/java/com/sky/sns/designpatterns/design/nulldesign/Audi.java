package com.sky.sns.designpatterns.design.nulldesign;

public class Audi implements Vehicle{
    @Override
    public int getVehicleFuel() {
        return 1000;
    }

    @Override
    public int getVehicleMileage() {
        return 300;
    }
}
