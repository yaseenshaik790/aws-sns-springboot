package com.sky.sns.service;


import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Test {

    static List<String> list = new ArrayList<>();
    public static void main(String[] args) {

        String key = "oauthSecret";

        String data = "{\n" +
                "    \"creationDateFrom\": \"2021-10-20 00:10:03\",\n" +
                "    \"creationDateTo\": \"2022-12-29 18:10:03\",\n" +
                "    \"accountId\": [\n" +
                "        \"6700005936\"\n" +
                "    ],\n" +
                "    \"status\": [\n" +
                "        \"Approved\",\n" +
                "        \"Rejected\"\n" +
                "    ],\n" +
                "    \"incoTerm1Code\": [\n" +
                "        \"FCA\",\n" +
                "        \"DAP\"\n" +
                "    ],\n" +
                "    \"commodityGroupCode\": [\n" +
                "        \"MILLING_WHEAT\",\n" +
                "        \"CORN\"\n" +
                "    ],\n" +
                "    \"valuationPointId\": [\n" +
                "        \"9HZH SMSH B2\",\n" +
                "        \"9HZH SMSH B1\"\n" +
                "    ],\n" +
                "    \"commodityId\": [\n" +
                "        \"000000000199700\",\n" +
                "        \"000000000199700234\"\n" +
                "    ]\n" +
                "}";

        JSONObject json = new JSONObject(data);
        //JSONArray jsonArray = json.
    }



}
