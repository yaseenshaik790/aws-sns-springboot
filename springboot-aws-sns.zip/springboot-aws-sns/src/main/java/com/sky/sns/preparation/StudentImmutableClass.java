package com.sky.sns.preparation;

import java.util.HashMap;
import java.util.Iterator;

public final class StudentImmutableClass {
    private final Integer id;
    private final String name;
    private final HashMap<String, String> testMap;

    public StudentImmutableClass(Integer id, String name, HashMap<String, String> hm) {
        this.id = id;
        this.name = name;
        HashMap<String, String> tempMap = new HashMap<>();
        String key;
        for (String s : hm.keySet()) {
            key = s;
            tempMap.put(key, hm.get(key));
        }
        this.testMap = tempMap;
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public HashMap<String, String> getTestMap() {
        return (HashMap<String, String>) testMap.clone();
    }

    public static void main(String[] args) {
        HashMap<String, String> hm = new HashMap<>();
        hm.put("1", "Yaseen");
        hm.put("2", "Harsha");
        Integer id = 10;
        String name = "Yaseen";
        StudentImmutableClass aClass = new StudentImmutableClass(id, name, hm);

        System.out.println(" ID "+aClass.getId());
        System.out.println(" Name "+aClass.getName());
        System.out.println(" Map "+aClass.getTestMap());

        id = 20;
        name = "Jack";
        hm.put("3", "Bellamy");
        System.out.println(" ID "+aClass.getId());
        System.out.println(" Name "+aClass.getName());
        System.out.println(" Map "+aClass.getTestMap());
    }
}
