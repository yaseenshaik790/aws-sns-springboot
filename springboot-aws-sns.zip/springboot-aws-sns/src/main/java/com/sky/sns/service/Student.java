package com.sky.sns.service;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Student {

    private Integer id;
    private String name;
    private String address;
    //private Department department;
}
