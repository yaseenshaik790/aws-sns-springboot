package com.sky.sns.preparation;

import lombok.NoArgsConstructor;

@NoArgsConstructor
class A{
    int X = 10;
    public void print(){
        System.out.println("Print A");
    }
}
@NoArgsConstructor
class B extends A{
    int X = 20;
    public void print(){
        System.out.println("Print B");
    }
}
public class UpAndDownCasting {
    public static void main(String[] args) {
        //Converting sub class to super class is upcasting
        //SUper class properties are hidden and sub class will be printen
        A a = new B();
        a.print(); // Sub class printes
        System.out.println(a.X); // SUper class prints
        B b = (B) a;
        b.print(); // Sub class printes
        System.out.println(b.X); // Sub class printes
    }
}
