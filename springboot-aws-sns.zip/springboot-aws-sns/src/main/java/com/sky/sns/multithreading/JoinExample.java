package com.sky.sns.multithreading;

class Demo extends Thread {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            try {
                Thread.sleep(500);
            } catch (Exception e) {
                System.out.println(e);
            }
            System.out.println(i);
        }
    }
}

public class JoinExample {
    public static void main(String[] args) throws InterruptedException {
        Demo demo = new Demo();
        Thread t1 = new Thread(demo);
        Thread t2 = new Thread(demo);
        Thread t3 = new Thread(demo);
        //Join method will pause the current thread and keep it in wait until the current thread is terminated
        t1.start();
        t1.join();
        t2.start();
        t2.join();
        t3.start();
        t3.join();
        //Without join it will print randomly and execute threads randomly
        //t1.start();
        //t2.start();
        //t3.start();
    }
}
