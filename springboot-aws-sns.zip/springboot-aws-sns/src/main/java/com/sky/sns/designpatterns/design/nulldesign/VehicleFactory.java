package com.sky.sns.designpatterns.design.nulldesign;

public class VehicleFactory {

    public static Vehicle getVehicle(Vehicle vehicle){
        if (vehicle instanceof Audi){
            return new Audi();
        } else if (vehicle instanceof Mercedes){
            return new Mercedes();
        } else {
            return new EmptyObject();
        }

    }
}
