package com.sky.sns.designpatterns.NullObjectDesignPatter;

public interface Vehicle {

    int getFuelCapacity();
    String getVehicleName();
}
