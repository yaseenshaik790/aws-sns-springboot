package com.sky.sns.multithreading;

class DemoTwo extends Thread {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            try {
                Thread.sleep(500);
            } catch (Exception e) {
                System.out.println(e);
            }
            System.out.println(i);
        }
    }
}
public class DaemonThread {
    public static void main(String[] args) {
        //Daemon Thread is service provider. The live of the daemon thread is dependent on other threads.
        //example finalizer before killing the object it will remove all the connections

        DemoTwo demoTwo = new DemoTwo();
        Thread thread = new Thread(demoTwo);
        Thread thread2 = new Thread(demoTwo);
        thread.setDaemon(true);
        thread.start();
        thread2.start();
    }
}
