package com.sky.sns.lld.loggingsystem;

public class Client {
    public static void main(String[] args) {
        LogProcessor processor = new InfoLogProcessor(new DebugLogProcessor(new ErrorLogProcessor(null)));
        processor.log(LogProcessor.ERROR," Error find out");
        processor.log(LogProcessor.DEBUG," Debug to be done");
        processor.log(LogProcessor.INFO," Info FYI");
    }
}
