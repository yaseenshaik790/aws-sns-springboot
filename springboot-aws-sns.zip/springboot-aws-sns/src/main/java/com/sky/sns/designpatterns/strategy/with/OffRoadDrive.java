package com.sky.sns.designpatterns.strategy.with;

import com.sky.sns.designpatterns.strategy.with.strategy.SpecialDriveCapability;

public class OffRoadDrive extends VehicleFactory {

    public OffRoadDrive(){
        super(new SpecialDriveCapability());
    }
}
