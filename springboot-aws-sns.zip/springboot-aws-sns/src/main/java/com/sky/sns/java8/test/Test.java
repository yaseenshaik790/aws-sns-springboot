package com.sky.sns.java8.test;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.*;
import java.util.stream.Collectors;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
class Employee{
    int id;
    String name;
    Double sal;
}

public class Test {
    public static void main(String[] args) {
        List<Employee> list = new ArrayList<>();
        list.add(new Employee(1,"h",2000.00));
        list.add(new Employee(2,"a",2030.00));
        list.add(new Employee(3,"r",2020.00));
        list.add(new Employee(5,"t",20110.00));
        list.add(new Employee(4,"a",20330.00));

        //Asceneding
        List<Employee> employees = list.stream().sorted(Comparator.comparingInt(Employee::getId))
                .collect(Collectors.toList());
        employees.forEach(emp3 -> System.out.println("Asc " + emp3.getId()+" "));

        //Desc order
        List<Employee> employ = list.stream().sorted(Comparator.comparingInt(Employee::getId).reversed())
                .collect(Collectors.toList());
        employ.forEach(emp -> System.out.println("Desc "+emp.getId()+" "));


        //Sal list
        List<Double> sal = list.stream().map(Employee::getSal).collect(Collectors.toList());
        System.out.println("Only Sal "+sal);

        //Only Sum of Salaries
        Double sumValue = list.stream().mapToDouble(Employee::getSal).sum();
        System.out.println("Sum Sal "+sumValue);

        //Max Double
        Double maxValue = list.stream().max(Comparator.comparingDouble(Employee::getSal))
                .map(Employee::getSal).get();
        System.out.println("Max Sal "+maxValue);

        //Min Double
        Double minSal = list.stream().min(Comparator.comparingDouble(Employee::getSal))
                .map(Employee::getSal).get();
        System.out.println("Min Sal "+minSal);

        //Set
        Set<Double> salary = list.stream().map(Employee::getSal).collect(Collectors.toSet());
        System.out.println("Set "+salary);

        //map
        Map<Integer, String> map = list.stream().collect(Collectors.toMap(Employee::getId, Employee::getName));
        System.out.println("map "+map);

        //FlatMap : Performs Map operation and flattering operations
        List<List<Integer>> ints = Arrays.asList(Arrays.asList(5, 7, 11,13),Arrays.asList(1, 3, 5),Arrays.asList(2, 4, 6, 8));

        List<Integer> finalSal = ints.stream().flatMap(Collection::stream).collect(Collectors.toList());
        System.out.println("After flattering "+finalSal);

    }
}













    /*List<Double> sal = list.stream().map(Employee::getSal)
            .filter(employeeSal -> employeeSal > 200).collect(Collectors.toList());
        System.out.println(sal);
        //Only Price
        Double value = list.stream().map(Employee::getSal).reduce(0.0,Double::sum);
        System.out.println("Sum "+value);
        //Summing Double
        double price = list.stream().mapToDouble(Employee::getSal).sum();
        System.out.println("Summing Double "+price);
        //Max Double
        Employee maxPrice = list.stream().max(Comparator.comparing(Employee::getSal)).get();
        System.out.println("Max "+maxPrice.getSal());
        //Min Double
        Employee minPrice = list.stream().min(Comparator.comparing(Employee::getSal)).get();
        System.out.println("Min "+minPrice.getSal());
        //Set
        Set<Double> hashSet = list.stream().map(Employee::getSal).collect(Collectors.toSet());
        System.out.println("Set "+hashSet);
        //map
        Map<Integer,String> map = list.stream().collect(Collectors.toMap(Employee::getId,Employee::getName));
        System.out.println("map "+map);*/
