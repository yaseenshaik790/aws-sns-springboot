package com.sky.sns.multithreading;

import lombok.*;

@AllArgsConstructor
@Data
@NoArgsConstructor
class Student implements Runnable {
    int id;
    String name;

    @SneakyThrows
    @Override
    public void run() {
        for (int i=0; i< 2; i++){
            Thread.sleep(3000);
            System.out.println(id+" "+name);
        }
    }
}
public class Executer {

    public static void main(String[] args) throws InterruptedException {
        Student student = new Student(1,"HI");
        Student studentTwo = new Student(2,"Hello");
        Thread t1 = new Thread(student);
        Thread t2 = new Thread(studentTwo);
        t1.start();
        Thread.yield();
        t2.start();
    }
}
