package com.sky.sns.designpatterns.strategy.without;

public class Vehicle {

    public void drive() {
        System.out.println("Normal Drive Capability");
    }
}
