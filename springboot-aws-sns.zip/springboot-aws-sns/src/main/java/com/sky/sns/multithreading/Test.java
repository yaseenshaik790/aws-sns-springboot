package com.sky.sns.multithreading;

public class Test {

    public static void main(String[] args) {

    }
}
